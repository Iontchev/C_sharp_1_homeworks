﻿using System;

class CompanyInfo
{
    static void Main()
    {
        Console.Write("Please enter company name: ");
        string companyName = Console.ReadLine();
        Console.Write("Please enter company addres: ");
        string companyAddres = Console.ReadLine();
        Console.Write("Please enter phone number: ");
        int companyPhone = int.Parse(Console.ReadLine());
        Console.Write("Please enter fax number: ");
        int companyFax = int.Parse(Console.ReadLine());
        Console.Write("Please enter site: ");
        string companySite = Console.ReadLine();
        Console.Write("Please enter Manager first name: ");
        string managerFirstName = Console.ReadLine();
        Console.Write("Please enter Manager last name: ");
        string managerLastName = Console.ReadLine();
        Console.Write("Please enter Manager age: ");
        int managerAge = int.Parse(Console.ReadLine());
        Console.Write("Please enter Manager phone number: ");
        int managerPhone = int.Parse(Console.ReadLine());
        Console.WriteLine("Company name:        :" + companyName);
        Console.WriteLine("Company addres:      :" + companyAddres);
        Console.WriteLine("Company phone:       :" + companyPhone);
        Console.WriteLine("Company fax:         :" + companyFax);
        Console.WriteLine("Company site:        :" + companySite);
        Console.WriteLine("Manager first name:  :" + managerFirstName);
        Console.WriteLine("Manager last name:   :" + managerLastName);
        Console.WriteLine("Manager age:         :" + managerAge);
        Console.WriteLine("Manager phone:       :" + managerPhone);
    }
}

