﻿using System;



class AddThreenumbers
{
    static void Main()
    {
        int firstNumber = int.Parse(Console.ReadLine());
        int secondNumber = int.Parse(Console.ReadLine());
        int thirdNumber = int.Parse(Console.ReadLine());
        Console.WriteLine(firstNumber+secondNumber+thirdNumber);
    }
}

