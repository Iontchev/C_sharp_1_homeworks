﻿using System;

class SumOfNNumbers
{
    static void Main()
    {
        Console.Write("Please enter a number: ");
        uint n = uint.Parse(Console.ReadLine());
        double sum = 0;
        double newnember;
        while (n > 0)
        {
            newnember = double.Parse(Console.ReadLine());
            sum = sum + newnember;
            n--;
        }
        Console.WriteLine(sum);
    }
}

