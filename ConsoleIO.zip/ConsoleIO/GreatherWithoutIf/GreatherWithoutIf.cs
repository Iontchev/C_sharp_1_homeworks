﻿using System;

    class GreatherWithoutIf
    {
        static void Main()
        {
            Console.Write("Please enter first number : ");
            double firstNumber = double.Parse(Console.ReadLine());
            Console.Write("Please enter second number: ");
            double secondNumber = double.Parse(Console.ReadLine());
            Console.WriteLine((firstNumber > secondNumber) ? firstNumber : secondNumber);
        }
    }

