﻿using System;

class NumbersDevidedByFive
{
    static void Main()
    {
        Console.Write("Please enter first number : ");
        uint firstNumber = uint.Parse(Console.ReadLine());
        Console.Write("Please enter second number: ");
        uint secondNumber = uint.Parse(Console.ReadLine());
        uint counter = 0;
        if (firstNumber > secondNumber)
        {
            for (uint i = secondNumber; i <= firstNumber; i++)
            {
                if (i % 5 == 0)
                {
                    counter++;
                }
            }
        }
        else
        {
            for (uint i = firstNumber; i <= secondNumber; i++)
            {
                if (i % 5 == 0)
                {
                    counter++;
                }
            }       
        }
        Console.WriteLine(counter);
    }
}

