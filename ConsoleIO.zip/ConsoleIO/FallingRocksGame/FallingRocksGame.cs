﻿using System;
using System.Threading;
using System.Threading.Tasks;

class FallingRocksGame
{
    static void Main()
    {
        // declare matrix with 20 lines and 20 simbols
        char [,] rows = { {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '},
                          {' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '}};
        char generated;
        ConsoleKeyInfo consoleInput;
        char [] myPosition = {' ',' ',' ',' ',' ',' ',' ',' ','(','0',')',' ',' ',' ',' ',' ',' ',' ',' ',' '};
        int myArrayPosition = 9;
        Random getrandomchar = new Random();
        Random getrandomcharshow = new Random();
        String[] colorNames = { "Blue", "Cyan", "DarkBlue", "Gray","Magenta","Yellow","Red","DarkYellow","White","DarkCyan","DarkRed","DarkMagenta"};
        while (rows[19, myArrayPosition] == ' ') //check if there is a 'rock' over my position, if yes - game ends, if not adds new line
        {
            for (int slow = 20; slow < 150; slow = slow + 20)
            {
                while (Console.KeyAvailable)
                {
                    consoleInput = Console.ReadKey();
                    if (consoleInput.Key == ConsoleKey.LeftArrow)
                    {
                        if (myPosition[1] == ' ')
                        {
                            for (int i = 0; i < 19; i++)
                            {
                                myPosition[i] = myPosition[i + 1];
                                myPosition[19] = ' ';
                            }
                            myArrayPosition = myArrayPosition - 1;
                        }
                    }
                    if (consoleInput.Key == ConsoleKey.RightArrow)
                    {
                        if (myPosition[19] == ' ')
                        {
                            for (int i = 19; i > 0; i--)
                            {
                                myPosition[i] = myPosition[i - 1];
                                myPosition[0] = ' ';
                            }
                            myArrayPosition = myArrayPosition + 1;
                        }
                    }
                }
                Thread.Sleep(slow);
            }
            for (int k = 19; k > 0; k--) // moves all one line down
            { 
                for (int l = 0; l < 20; l++)
                {
                    rows [k,l] = rows [k-1,l];
                }
            }
            for (int i = 0; i < 20; i++)  //add new values on first line 
            { 
                if (getrandomcharshow.Next(99) > 90)
                {
                    generated = (char)getrandomchar.Next(32, 40);
                }
                else
                {
                    generated = ' ';
                }
                rows [0,i] = generated;
            }
            Console.Clear();   // clear console and rewrite all with the new values
            for (int k = 0; k < 20; k++)
            {
                for (int l = 0; l < 20; l++)
                {  
                    //next line change console color with random color from the string array 
                    Console.ForegroundColor = (ConsoleColor)Enum.Parse(typeof(ConsoleColor), colorNames[getrandomchar.Next(colorNames.Length)]);
                    Console.Write( rows[k,l] );
                }
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine('|');
            }
            Console.Write(myPosition);
            Console.WriteLine('|');
            Console.WriteLine("--------------------|");
            Console.ForegroundColor = ConsoleColor.Black;
        }
        Console.ForegroundColor = ConsoleColor.White;
        Console.WriteLine ("GAME OVER");
    }
}

