﻿using System;

class PrintsNumsOneToN
{
    static void Main()
    {
        Console.Write("Please enter a number: ");
        uint n = uint.Parse(Console.ReadLine());
        for (int i = 1; i <= n; i++)
        {
            Console.WriteLine(i);
        }
    }
}

