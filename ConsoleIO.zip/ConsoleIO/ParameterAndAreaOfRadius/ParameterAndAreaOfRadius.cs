﻿using System;

    class PerimeterAndAreaOfRadius
{
    static void Main()
    {
        double radius = double.Parse(Console.ReadLine());
        Console.WriteLine(" The perimeter is " + 2*Math.PI*radius );
        Console.WriteLine(" The   area    is " + Math.PI * radius * radius);
    }
}

