﻿using System;

class AddingFractional
{
    static void Main()
    {
        double sum = 1;
        int i = 1;
        /*
        while (1 / i >= 0.001)
        {
            i++;
            sum += 1/ (Math.Pow (-1,i)*i); 
        } 
        */
        while (1000 / i >= 1)
        {
            i++;
            sum += 1 / (Math.Pow(-1, i) * i);
        }
        Console.WriteLine(sum);
    }
}

