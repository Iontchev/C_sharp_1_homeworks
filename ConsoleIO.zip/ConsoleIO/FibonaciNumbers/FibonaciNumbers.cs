﻿using System;

class FibonaciNumbers
{
    static void Main()
    {
        double num1 = 0;
        double num2 = 1;
        double sum = 1;
        Console.WriteLine(num1);
        Console.WriteLine(num2);
        for (int i = 0; i < 100; i++)
        {
            sum = num1 + num2;
            num1 = num2;
            num2 = sum;
            Console.WriteLine(num2);
        }
    }
}

