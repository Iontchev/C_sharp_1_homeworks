﻿using System;


class CompareFloatingNumbers
{
    static void Main()
    {
        double firstNumber;
        double secondNumber;
        Console.Write("Enter first number:");
        firstNumber = double.Parse(Console.ReadLine());
        Console.Write("Enter second number;");
        secondNumber = double.Parse(Console.ReadLine());
        if (Math.Abs(firstNumber - secondNumber) <= 0.000001)
        {
            Console.WriteLine("Numbers are equal");
        } 
        else
        {
             Console.WriteLine("Numbers are not equal");
        }
    }
}

