﻿using System;

class IsoscaleTriangleOfChars
{
    static void Main()
    {
        char copyRight = '\u00A9';
        for (int i = 1; i <= 3; i++)      // write last symbol and goes to new line
        {
            for (int k = 1; k <= 3 - i; k++)    // write 3-i empty spaces
            {
                Console.Write('\0');
            }
            for (int j = 1; j < i*2-1; j++)     // write symbols 0, two or four times
            {
                Console.Write(copyRight);
            }
            Console.WriteLine(copyRight);
        }
    }
}

