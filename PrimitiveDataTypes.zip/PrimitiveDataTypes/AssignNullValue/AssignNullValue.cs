﻿using System;

class AssignNullValue
{
    static void Main()
    {
         int? intValue = null;
        double? doubleValue = null;
        Console.WriteLine(intValue);
        Console.WriteLine(doubleValue);
        intValue = 1;
        doubleValue = 1.1;
        Console.WriteLine(intValue);
        Console.WriteLine(doubleValue);
    } 
}

