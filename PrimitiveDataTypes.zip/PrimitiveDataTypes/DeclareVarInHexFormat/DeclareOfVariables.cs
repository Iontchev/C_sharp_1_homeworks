﻿using System;

class DeclareOfVariables
{
    static void Main()
    {
        int value = 0xFE;    // task 4.
        char simvol = '\u0048';   // task 5.
        bool isFemale = false;   //task 6.
        string firstWord = "Hello";    // task 7.
        string secondWord = "World";
        object concatinateTwoWords = firstWord + " " + secondWord;
        string CastedString = Convert.ToString(concatinateTwoWords);
        string stingWithQuote = @"The ""use"" of quotations causes difficulties";   // task 8
        string stingWithoutQuote = "The \"use\" of quotations causes difficulties";
    }
}

