﻿using System;

class FirmRecord
{
    static void Main()
    {
        string firstName;
        string familyName;
        byte age;
        bool isMale;
        ulong IDnumber;
        uint employeeNumber;

    }
}

