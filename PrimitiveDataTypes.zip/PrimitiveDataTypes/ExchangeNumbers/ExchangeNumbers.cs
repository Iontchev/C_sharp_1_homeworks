﻿using System;

class ExchangeNumbers
{
    static void Main()
    {
        int firstInt = 5;
        int secondInt = 10;
        int tempInt;
        tempInt = firstInt;
        firstInt = secondInt;
        secondInt = tempInt;
    }
}

