﻿using System;

class PrintACSIItable
{
    static void Main()
    {
        for (int i = 1; i <= 255; i++)
        {
            Console.WriteLine(" {0}--->{1}    ", i, (char)i);
        }
    }
}

