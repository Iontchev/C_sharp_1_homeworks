﻿using System;


class DeclareFiveVars
{
    static void Main()
    {
        ushort ushortData = 52130;
        sbyte sbiteData = -115;
        uint uintData = 4825932;
        byte byteData = 97;
        short shortData = 10000;
    }
}

