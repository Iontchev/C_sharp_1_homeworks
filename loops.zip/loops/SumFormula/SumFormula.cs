﻿using System;

class SumFormula
{
    static void Main()
    {
        Console.Write("Input x number:");
        int Xnum = int.Parse(Console.ReadLine());
        Console.Write("Input N number:");
        int Nnum = int.Parse(Console.ReadLine());
        float result = 1;
        float nfactoriel = 1;
        for (int i = 1; i <= Nnum; i++)
        {
            nfactoriel *= i;
            result = result + nfactoriel / (Xnum * i);
        }
        Console.WriteLine(result);
    }
}

