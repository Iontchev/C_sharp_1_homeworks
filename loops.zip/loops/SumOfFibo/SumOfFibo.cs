﻿using System;

class SumOfFibo
{
    static void Main()
    {
        Console.Write("Input N number:");
        int Nnum = int.Parse(Console.ReadLine());
        double num1 = 0;
        double num2 = 1;
        double sum = 1;
        double totalsum = 1;
        for (int i = 2; i < Nnum; i++)
        {
            sum = num1 + num2;
            num1 = num2;
            num2 = sum;
            totalsum += sum;
        }
        Console.WriteLine(totalsum);
    }

}

