﻿using System;

class GDC
{
    public static int GCD(int a, int b)
    {
        while (a != 0 && b != 0)
        {
            if (a > b)
                a %= b;
            else
                b %= a;
        }

        if (a == 0)
            return b;
        else
            return a;
    }
    static void Main()
    {
        Console.Write("Input first number:");
        int a = int.Parse(Console.ReadLine());
        Console.Write("Input second number:");
        int b = int.Parse(Console.ReadLine());
        int result;
        result = GCD(a,b);
      
        Console.WriteLine(result);
    }
}
