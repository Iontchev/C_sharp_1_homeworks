﻿using System;



class MatrixOfNumbers
{
    static void Main()
    {
        int number;
        Console.Write("Input a number:");
        do
        {
            number = int.Parse(Console.ReadLine());
        } while (number < 0);
        for (int i = 1; i <= number; i++)
        {
            for (int j = 0; j < number; j++)
            {
                Console.Write(" {0} ",i+j);
            }
            Console.WriteLine();
        }
    }
}

