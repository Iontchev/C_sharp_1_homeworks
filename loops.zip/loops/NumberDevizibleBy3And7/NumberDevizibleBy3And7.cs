﻿using System;

class NumberDevizibleBy3And7
{
    static void Main()
    {
        Console.Write("Input a number:");
        int number = int.Parse(Console.ReadLine());
        for (int i = 1; i <= number; i++)
            if (i != 21)
            {
                Console.WriteLine(i);
            }
    }
}

