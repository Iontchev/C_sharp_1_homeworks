﻿using System;

class spiral
{
    static int[,] matrix;
    static void Main()
    {
        int number;
        Console.Write("Input a number:");
        do
        {
            number = int.Parse(Console.ReadLine());
        } while (number < 0);
         matrix = new int[number,number];
        int i,j,value =1,circle = 0;
        do
        {
            value = MoveRight(number, circle, value);
            value = MoveDown(number, circle, value);
            value = MoveLeft(number, circle, value);
            value = MoveUp(number, circle, value);
            circle++;
        } while (value <= number * number);
        for (i = 0; i < number; i++)
        {
            for (j = 0; j < number; j++)
            {
                Console.Write("  ");
                Console.Write(matrix[i,j]);
                Console.Write("  ");
            }
            Console.WriteLine();
        }
    }
    static int MoveRight(int number, int circle, int value)
    {
        for (int i = 0; i < number - circle*2 ; i++)
        {
            matrix[circle, circle + i] = value;
            value++;
        }
        return value;
    }
    static int MoveDown(int number, int circle, int value)
    {
        for (int i = 0; i < number - circle*2 - 1 ; i++)
        {
                matrix[circle + 1 + i, number - circle - 1] = value;
                value++;
        }
        return value;
    }
    static int MoveLeft(int number, int circle, int value)
    {
        for (int i = 1; i < number - circle*2 ; i++)
        {
            matrix[number - circle - 1,number - circle - i - 1] = value;
            value++; 
        }
        return value;
    }
    static int MoveUp(int number, int circle, int value)
    {
        for (int i = 0; i < number - circle*2 - 2 ; i++)
        {
                matrix[number - circle - i - 2, circle ] = value;
                value++;
        }
        return value;
    }
}

