﻿using System;
using System.Numerics;

class ZerosInFactorial
{
    static void Main()
    {
        int number;
        Console.Write("Input a number:");
        do
        {
            number = int.Parse(Console.ReadLine());
        } while (number < 0);
        BigInteger factorial = 1;
        for (int i = 1; i <= number; i++)
        {
            factorial *= i; 
        }
        int zeros = 0;
        while ((factorial % 10) == 0)
        {
            zeros++;
            factorial /= 10;
        }
        Console.WriteLine("{0}  ->  {1}",factorial*(int)Math.Pow(10,zeros),zeros);
    }
}

