﻿using System;


class DevidesFactorials
{
    static void Main()
    {
        Console.Write("Input K number:");
        int Knum = int.Parse(Console.ReadLine());
        Console.Write("Input N number:");
        int Nnum = int.Parse(Console.ReadLine());
        float result;
        float numerator = 1, dominator = 1;
        for (int i = 1; i <= Knum; i++)
        {
            dominator *= i;
        }
        for (int i = 1; i <= Nnum; i++)
        {
            numerator *= i;
        }
        result = numerator / dominator;
        Console.WriteLine(result);
    }
}

