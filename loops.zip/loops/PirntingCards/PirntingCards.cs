﻿using System;


class PirntingCards
    {
        static void Main()
        {
            string[] suits = {"spades","heards","diamonds","clubs"};
            string[] rangs = { "Ase of ", "Two of ", "Three of ", "Four of ", "Five of ", "Six of ", "Seven of ", "Eight of ", "Nine of ", "Ten of ", "Jack of ", "Queen of ", "King of " };
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 13; j++)
                {
                    Console.WriteLine( rangs[j] + suits[i] );
                }
            }
        }
    }

