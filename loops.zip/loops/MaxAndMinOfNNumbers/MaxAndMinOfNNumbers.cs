﻿using System;
using System.Linq;

class MaxAndMinOfNNumbers
{
    static void Main()
    {
        Console.Write("Input a number:");
        int number = int.Parse(Console.ReadLine());
        int[] intstring = new int[number];
        for (int i = 0; i < number; i++ )
        {
            intstring[i] = int.Parse(Console.ReadLine());
        }
        Console.Write("Minimum is ");
        Console.WriteLine(intstring.Min());
        Console.Write("Maximim is ");
        Console.WriteLine(intstring.Max());
    }
}
