﻿using System;

class FactorialFormula
{
    static void Main()
    {
        Console.Write("Input K number:");
        int Knum = int.Parse(Console.ReadLine());
        Console.Write("Input N number:");
        int Nnum = int.Parse(Console.ReadLine());
        float result;
        float nfactoriel = 1, kfactoriel = 1, knfaktoriel = 1;
        for (int i = 1; i <= Knum; i++)
        {
            kfactoriel *= i;
        }
        for (int i = 1; i <= Nnum; i++)
        {
            nfactoriel *= i;
        }
         for (int i = 1; i <= (Knum-Nnum); i++)
        {
            knfaktoriel *= i;
         }
         result = kfactoriel * nfactoriel / knfaktoriel;
        Console.WriteLine(result);
    }
}

