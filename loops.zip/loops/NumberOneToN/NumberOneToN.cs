﻿using System;

class NumberOneToN
{
    static void Main()
    {
        Console.Write("Input a number:");
        int number = int.Parse(Console.ReadLine());
        for ( int i=1; i<=number; i++)
            Console.WriteLine(i);
    }
}

