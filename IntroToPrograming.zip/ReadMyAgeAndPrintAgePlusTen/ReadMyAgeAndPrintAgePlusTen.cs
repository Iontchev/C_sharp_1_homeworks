﻿using System;

class ReadMyAgeAndPrintAgePlusTen
{
    static void Main()
    {
        Console.WriteLine("Enter your age:");
        string line = Console.ReadLine(); // Read string from console
        int value;
        if (int.TryParse(line, out value)) // Try to parse the string as an integer
        {
            Console.Write("After 10 years you will be at ");
            Console.WriteLine(value + 10); //Adds 10 to integer and display it
        }
        else
        {
            Console.WriteLine("Error: You have not entered an integer!"); // If the input is not integer
        }
    }
}

