﻿using System;

class PrintDateAndTime
{
    static void Main()
    {
        Console.WriteLine(DateTime.Now);
    }
}

