﻿using System;

class ArapezoidArea
{
    static void Main()
    {
        Console.Write("Enter a: ");
        double a = double.Parse(Console.ReadLine());
        Console.Write("Enter b: ");
        double b = double.Parse(Console.ReadLine());
        Console.Write("Enter h: ");
        double h = double.Parse(Console.ReadLine());
        h = ( a + b ) * h / 2;
        Console.WriteLine( "Area is {0}", h);
    }
}
