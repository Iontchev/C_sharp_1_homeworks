﻿using System;

class EvenOrOdd
    {
        static void Main()
        {
            Console.Write("Enter a number: ");
            int i = int.Parse(Console.ReadLine());
            Console.WriteLine((i % 2) == 0 ? "Even" : "Odd");
        }
    }
