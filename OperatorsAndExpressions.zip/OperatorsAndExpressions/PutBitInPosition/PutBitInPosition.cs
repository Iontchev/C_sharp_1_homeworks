﻿using System;

class PutBitInPosition
{
    static void Main()
    {
        Console.Write("Enter a number: ");
        int number = int.Parse(Console.ReadLine());
        Console.Write("Enter position: ");
        int position = int.Parse(Console.ReadLine());
        Console.Write("Enter bit value: ");
        int bitValue = int.Parse(Console.ReadLine());
        int mask = 1;
        mask = mask << position;
        if (bitValue == 0)
        {
            number = number & ~mask;
        }
        else 
        {
            number = number | mask;
        }
        Console.WriteLine(number);
    }
}

