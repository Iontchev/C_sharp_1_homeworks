﻿using System;

class GiveValueOfBit
{
    static void Main()
    {
        byte value;
        Console.Write("Enter a number: ");
        int number = int.Parse(Console.ReadLine());
        Console.Write("Enter position: ");
        int position = int.Parse(Console.ReadLine());
        int mask = 1;
        mask = mask << position;
        bool boolean = (number & mask) == mask;
        if (boolean)
        {
            value = 1;
        }
        else
        {
            value = 0;
        }
        Console.WriteLine("the value of bit number {0} is {1}", position, value);
    }
}

