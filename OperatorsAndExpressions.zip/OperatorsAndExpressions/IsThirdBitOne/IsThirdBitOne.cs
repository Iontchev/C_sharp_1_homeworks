﻿using System;

class IsThirdBitOne
{
    static void Main()
    {
        Console.Write("Enter a number: ");
        int i = int.Parse(Console.ReadLine());
        int mask = 8;
        bool boolean = (i & mask) == 8;
        Console.WriteLine(boolean ? "Third bit is 1" : "Third bit is 0");
    }
}

