﻿using System;

class CheckIfBitIsOne
{
    static void Main()
    {
        Console.Write("Enter a number: ");
        int number = int.Parse(Console.ReadLine());
        Console.Write("Enter position: ");
        int position = int.Parse(Console.ReadLine());
        int mask = 1;
        mask = mask << position;
        bool boolean = (number & mask) == mask;
        if (boolean)
        {

            Console.WriteLine("The {0} bit is 1", position);
        }else
        {
            Console.WriteLine("The {0} bit is 0", position);
        }
    }
}

