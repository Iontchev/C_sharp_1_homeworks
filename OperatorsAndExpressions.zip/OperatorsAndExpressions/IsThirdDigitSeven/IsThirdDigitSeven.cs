﻿using System;

class IsThirdDigitSeven
{
    static void Main()
    {
        Console.Write("Enter a number: ");
        int i = int.Parse(Console.ReadLine());

        Console.WriteLine((i / 100) % 10 == 7 ? "The third digit is 7" : "The third digit is NOT 7");
    }
}

