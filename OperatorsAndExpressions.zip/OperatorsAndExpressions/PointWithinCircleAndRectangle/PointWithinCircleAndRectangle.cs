﻿using System;

class PointWithinCircleAndRectangle
{
    static void Main()
    {
        Console.Write("Enter x: ");
        double x = double.Parse(Console.ReadLine());
        Console.Write("Enter y: ");
        double y = double.Parse(Console.ReadLine());
        bool isInCircle = (x - 1) * (x - 1) + (y - 1) * (y - 1) - 9 < 0;
        int top=1;
        int left=-1;
        int width=6;
        int height = 2;
        bool isInRectangle = (x > left && x < left + width) && (y > top - height && y < top);
        Console.WriteLine( isInCircle && !isInRectangle ? ";Yes, this point is in the circle and out of the rectangle!" : "No, this point is out of the circle or in the rectangle!");
    }
}

