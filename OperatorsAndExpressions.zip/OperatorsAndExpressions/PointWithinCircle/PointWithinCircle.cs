﻿using System;

class PointWithinCircle
{
    static void Main()
    {
        Console.Write("Enter x: ");
        double x = double.Parse(Console.ReadLine());
        Console.Write("Enter y: ");
        double y = double.Parse(Console.ReadLine());
        bool boolean = x*x+y*y-25 < 0;
        Console.WriteLine(boolean ? "this point is within the circle" : "this point is out the circle");
    }
}

