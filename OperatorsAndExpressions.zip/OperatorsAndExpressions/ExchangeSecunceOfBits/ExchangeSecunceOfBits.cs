﻿using System;

class ExchangeSecunceOfBits
{
    static void Main()
    {
        Console.Write("Enter a number: ");
        uint number = uint.Parse(Console.ReadLine());
        Console.Write("Enter factor P: ");
        uint firstSecuencetP = uint.Parse(Console.ReadLine());
        Console.Write("Enter factor Q: ");
        uint secondScuenceQ= uint.Parse(Console.ReadLine());
        Console.Write("Enter factor K: ");
        uint addedFactorK = uint.Parse(Console.ReadLine());
   
      
        uint x = 0;
        do 
        {
            uint bitMaskP = (uint)Math.Pow(2, firstSecuencetP+x);
            uint bitMaskQ = (uint)Math.Pow(2, secondScuenceQ+x);
            uint tempP = number & bitMaskP;
            uint tempQ = number & bitMaskQ;
            if (tempP == 0)
            {
                number = number & ~(bitMaskP << (int)(secondScuenceQ - firstSecuencetP));
            }
            else
            {
                number = number | (bitMaskP << (int)(secondScuenceQ - firstSecuencetP));
            }
            if (tempQ == 0)
            {
                number = number & ~(bitMaskQ >> (int)(secondScuenceQ - firstSecuencetP));
            }
            else
            {
                number = number | (bitMaskQ >> (int)(secondScuenceQ - firstSecuencetP));
            }

            x++;
           
        } while ( x < addedFactorK );

        Console.WriteLine(number);
    }
}

