﻿using System;


class RactangleArea
{
    static void Main()
    {
        Console.Write("Enter rectangle  widht: ");
        double widht = double.Parse(Console.ReadLine()); 
        Console.Write("Enter rectangle height: ");
        double height = double.Parse(Console.ReadLine());
        double area = widht * height;
        Console.WriteLine("Rectangle\'s area is: {0}",area);
    }
}

