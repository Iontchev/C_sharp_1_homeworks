﻿using System;

class IsPrime
{
    static void Main()
    {
        bool boolean = true;
        Console.Write("Enter a number: ");
        int inputNumber = int.Parse(Console.ReadLine());
        for (int i = 2; i < inputNumber; i++)
        {
            if (inputNumber % i == 0)
            {
                boolean = false;
                break;
            }
        }
        Console.WriteLine(boolean ? "This number is prime" : "This number is NOT prime");
    }
}

