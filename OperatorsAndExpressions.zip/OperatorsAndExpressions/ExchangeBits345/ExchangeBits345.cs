﻿using System;



class ExchangeBits345
{
    static void Main()
    {
        Console.Write("Enter a number: ");
        uint number = uint.Parse(Console.ReadLine());
        uint bitMask3 = (uint)Math.Pow(2, 3);
        uint bitMask4 = (uint)Math.Pow(2, 4);
        uint bitMask5 = (uint)Math.Pow(2, 5);
        uint bitMask24 = (uint)Math.Pow(2, 24);
        uint bitMask25 = (uint)Math.Pow(2, 25);
        uint bitMask26 = (uint)Math.Pow(2, 26);
        uint tempLowBits;
        uint tempHighBits;

        // chening bits 3 and 24

        tempLowBits = number & bitMask3;
        tempHighBits = number & bitMask24;
        if (tempLowBits == 0)
        {
            number = number & ~bitMask24;
        }
        else
        {
            number = number | bitMask24;
        }
        if (tempHighBits == 0)
        {
            number = number & ~bitMask3;
        }
        else
        {
            number = number | bitMask3;
        }

        // changing bits 4 and 25

        tempLowBits = number & bitMask4;
        tempHighBits = number & bitMask25;
        if (tempLowBits == 0)
        {
            number = number & ~bitMask25;
        }
        else
        {
            number = number | bitMask25;
        }
        if (tempHighBits == 0)
        {
            number = number & ~bitMask4;
        }
        else
        {
            number = number | bitMask4;
        }

        //changing bits 5 and 26

        tempLowBits = number & bitMask5;
        tempHighBits = number & bitMask26;
        if (tempLowBits == 0)
        {
            number = number & ~bitMask26;
        }
        else
        {
            number = number | bitMask26;
        }
        if (tempHighBits == 0)
        {
            number = number & ~bitMask5;
        }
        else
        {
            number = number | bitMask5;
        }


        Console.WriteLine(number);
    }
}

