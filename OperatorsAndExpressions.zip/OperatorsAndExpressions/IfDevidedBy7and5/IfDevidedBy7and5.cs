﻿using System;

class IfDevidedBy7and5
{
    static void Main()
    {
        Console.Write("Enter a number: ");
        int i = int.Parse(Console.ReadLine());
        bool boolean = (i % 5 == 0 && i % 7 == 0);
        Console.WriteLine( boolean ? "This number can be divided by 5 and 7" : "This number can  NOT be divided by 5 and 7");
    }
}

