﻿using System;


class BigestOf3
{
    static void Main()
    {
        double firstNum;
        double secondNum;
        double thirdNum;
        bool sign = true;
        Console.Write("Enter first number:");
        firstNum = double.Parse(Console.ReadLine());
        Console.Write("Enter second number:");
        secondNum = double.Parse(Console.ReadLine());
        Console.Write("Enter third number:");
        thirdNum = double.Parse(Console.ReadLine());
        if (firstNum > secondNum)
        {
            if (firstNum > thirdNum)
            {
                Console.WriteLine("The first nuber is Bigest.");
            }
            else
            {
                Console.WriteLine("The third nuber is Bigest.");

            }
        }
        else
        {
            if(secondNum > thirdNum)
            {
                Console.WriteLine("The second nuber is Bigest.");
            }
            else
            {
                Console.WriteLine("The third nuber is Bigest.");
            }
        }
    }
}

