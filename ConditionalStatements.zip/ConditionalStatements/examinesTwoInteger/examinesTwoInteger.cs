﻿using System;

class examinesTwoInteger
{
    static void Main()
    {
        int firstInt;
        int secondInt;
        Console.Write("Enter first number:");
        firstInt = int.Parse(Console.ReadLine());
        Console.Write("Enter second number:");
        secondInt = int.Parse(Console.ReadLine());
        if (firstInt > secondInt)
        {
            int temp = secondInt;
            secondInt = firstInt;
            firstInt = temp;
            Console.WriteLine("First number is grather");
        }
        else
        {
            Console.WriteLine("First number is not grather");
        }
    }
}

