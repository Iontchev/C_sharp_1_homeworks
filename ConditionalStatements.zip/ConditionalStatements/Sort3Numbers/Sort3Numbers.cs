﻿using System;

class Sort3Numbers
{
    static void Main()
    {
        double firstNum;
        double secondNum;
        double thirdNum;
        double temp;
        Console.Write("Enter first number:");
        firstNum = double.Parse(Console.ReadLine());
        Console.Write("Enter second number:");
        secondNum = double.Parse(Console.ReadLine());
        Console.Write("Enter third number:");
        thirdNum = double.Parse(Console.ReadLine());
        if (firstNum < secondNum)
        {
            temp = firstNum;
            firstNum = secondNum;
            secondNum = temp;
            if (firstNum < thirdNum)
            {
                temp = firstNum;
                firstNum = thirdNum;
                thirdNum = temp;
                if (secondNum < thirdNum)
                {
                    temp = secondNum;
                    secondNum = thirdNum;
                    thirdNum = temp;
                }
            }
            else
            {
                if (secondNum < thirdNum)
                {
                    temp = secondNum;
                    secondNum = thirdNum;
                    thirdNum = temp;
                }
            }
        }
        else
        {
            if (firstNum < thirdNum)
            {
                temp = firstNum;
                firstNum = thirdNum;
                thirdNum = temp;
                if (secondNum < thirdNum)
                {
                    temp = secondNum;
                    secondNum = thirdNum;
                    thirdNum = temp;
                }
            }
            else
            {
                if (secondNum < thirdNum)
                {
                    temp = secondNum;
                    secondNum = thirdNum;
                    thirdNum = temp;
                }
            }
        }
        Console.WriteLine(firstNum);
        Console.WriteLine(secondNum);
        Console.WriteLine(thirdNum);
    }
}

