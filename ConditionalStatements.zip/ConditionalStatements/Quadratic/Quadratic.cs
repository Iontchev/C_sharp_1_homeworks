﻿using System;

class QuadraticEquation
{
    static void Main()
    {
        Console.Write("Please enter parameter a : ");
        double a = double.Parse(Console.ReadLine());
        Console.Write("Please enter parameter b : ");
        double b = double.Parse(Console.ReadLine());
        Console.Write("Please enter parameter c : ");
        double c = double.Parse(Console.ReadLine());
        double x1, x2;
        double insideSquareRoot = (b * b) - 4 * a * c;
        if (insideSquareRoot < 0)
        {
            Console.WriteLine("No solutuion");
        }
        else
        {
            double sqrt = Math.Sqrt(insideSquareRoot);
            x1 = (-b + sqrt) / (2 * a);
            x2 = (-b - sqrt) / (2 * a);
            Console.WriteLine("X1 :" + x1);
            Console.WriteLine("X2 :" + x2);
        }

    }
}


