﻿using System;

    class ConvertNumberToText
    {
        static void Main()
        {
            Console.Write("Input a number:");
            int input = int.Parse(Console.ReadLine());
            int units;
            int tens;
            int hundreds;
            string text = " ";
            if (input >= 0 && input <= 999)
            {
                units = input % 10;
                tens = (input/10) % 10;
                hundreds = (input/100) % 10;
                switch (hundreds)
                {
                    case 0:
                        text = " ";
                        break;
                    case 1:
                        text = "one hundred";
                        break;
                    case 2:
                        text = "two hundred";
                        break;
                    case 3:
                        text = "three hundred";
                        break;
                    case 4:
                        text = "four hundred";
                        break;
                    case 5:
                        text = "five hundred";
                        break;
                    case 6:
                        text = "six hundred";
                        break;
                    case 7:
                        text = "seven hundred";
                        break;
                    case 8:
                        text = "eight hundred";
                        break;
                    case 9:
                        text = "nine hundred";
                        break;
                   
                }
                switch (tens)
                {
                    case 0:
                        switch (units)
                        {
                            case 1:
                                text = text + " and one";
                                break;
                            case 2:
                                text = text + " and two";
                                break;
                            case 3:
                                text = text + " and three";
                                break;
                            case 4:
                                text = text +  " and fourt";
                                break;
                            case 5:
                                text = text +  " and five";
                                break;
                            case 6:
                                text = text +  " and six";
                                break;
                            case 7:
                                text = text +  " and seven";
                                break;
                            case 8:
                                text = text +  " and eight";
                                break;
                            case 9:
                                text =  text + " and nine";
                                break;
                        }
                        break;
                    case 1:
                        switch (units)
                        {
                        case 0:
                            text = text + " and ten";
                            break;
                        case 1:
                            text = text + " and eleven";
                            break;
                        case 2:
                            text = text + " and twelve";
                            break;
                        case 3:
                            text = text + " and thirteen";
                            break;
                        case 4:
                            text = text + " and fourteen";
                            break;
                        case 5:
                            text = text + " and fifteen";
                            break;
                        case 6:
                            text = text + " and sixteen";
                            break;
                        case 7:
                            text = text + " and seventeen";
                            break;
                        case 8:
                            text = text + " and eighteen";
                            break;
                        case 9:
                            text = text + " and nineteen";
                            break;
                            }
                        break;
                    case 2:
                        text = text + " twenty";
                        break;
                    case 3:
                        text = text + " thirty";
                        break;
                    case 4:
                        text = text + " fourty";
                        break;
                    case 5:
                        text = text + " fifty";
                        break;
                    case 6:
                        text = text + " sixty";
                        break;
                    case 7:
                        text = text + " seventy";
                        break;
                    case 8:
                        text = text + " eighty";
                        break;
                    case 9:
                        text = text + " ninety";
                        break;

                }
                if (tens > 1)
                {
                    switch (units)
                    {
                        case 1:
                            text = text + " one";
                            break;
                        case 2:
                            text = text + " two";
                            break;
                        case 3:
                            text = text + " three";
                            break;
                        case 4:
                            text = text + " four";
                            break;
                        case 5:
                            text = text + " five";
                            break;
                        case 6:
                            text = text + " six";
                            break;
                        case 7:
                            text = text + " seven";
                            break;
                        case 8:
                            text = text + " eight";
                            break;
                        case 9:
                            text = text + " nine";
                            break;
                    }

                }
            }
            Console.WriteLine(text);
        }
    }
