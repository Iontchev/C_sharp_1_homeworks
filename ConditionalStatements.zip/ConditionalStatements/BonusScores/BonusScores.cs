﻿using System;



class BonusScores
{
    static void Main()
    {
        Console.Write("Enter a score:");
        double score = double.Parse(Console.ReadLine());
        string input;
        Console.Write("Enter a digit:");
        input = (Console.ReadLine());
        int digit;
        if (int.TryParse(input, out digit))
        {
            if (digit > 0 && digit <= 9)
            {
                switch (digit)
                {
                    case 1:
                        score = score * 10;
                        Console.WriteLine(score);
                        break;
                    case 2:
                        score = score * 10;
                        Console.WriteLine(score);
                        break;
                    case 3:
                        score = score * 10;
                        Console.WriteLine(score);
                        break;
                    case 4:
                        score = score * 100;
                        Console.WriteLine(score);
                        break;
                    case 5:
                        score = score * 100;
                        Console.WriteLine(score);
                        break;
                    case 6:
                        score = score * 100;
                        Console.WriteLine(score);
                        break;
                    case 7:
                        score = score * 1000;
                        Console.WriteLine(score);
                        break;
                    case 8:
                        score = score * 1000;
                        Console.WriteLine(score);
                        break;
                    case 9:
                        score = score * 1000;
                        Console.WriteLine(score);
                        break;
                    default:
                        Console.WriteLine("Invalid enter:");
                        break;
                }
            }
            Console.WriteLine("Wrong input");
        }
        else
        {
            Console.WriteLine("Wrong input");
        }
    }
}

