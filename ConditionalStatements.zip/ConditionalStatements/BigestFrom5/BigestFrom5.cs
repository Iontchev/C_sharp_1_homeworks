﻿using System;

class BigestFrom5
{
    static void Main()
    {
        double firstNum;
        double secondNum;
        double thirdNum;
        double fourthNum;
        double fifthNum;
        Console.Write("Enter first number:");
        firstNum = double.Parse(Console.ReadLine());
        Console.Write("Enter second number:");
        secondNum = double.Parse(Console.ReadLine());
        Console.Write("Enter third number:");
        thirdNum = double.Parse(Console.ReadLine());
        Console.Write("Enter fourth number:");
        fourthNum = double.Parse(Console.ReadLine());
        Console.Write("Enter fifth number:");
        fifthNum = double.Parse(Console.ReadLine());
        double bigest = fifthNum;
        if (firstNum > secondNum && firstNum > thirdNum && firstNum > fourthNum && firstNum > fifthNum)
        {
            bigest = firstNum;
        }
        if (secondNum > firstNum && secondNum > thirdNum && secondNum > fourthNum && secondNum > fifthNum)
        {
            bigest = secondNum;
        }
        if (thirdNum > secondNum && thirdNum > firstNum && thirdNum > fourthNum && thirdNum > fifthNum)
        {
            bigest = thirdNum;
        }
        if (fourthNum > secondNum && fourthNum > thirdNum && fourthNum > firstNum && fourthNum > fifthNum)
        {
            bigest = fourthNum;
        }
        Console.WriteLine("The greatest number is {0}",bigest);
    }
}

