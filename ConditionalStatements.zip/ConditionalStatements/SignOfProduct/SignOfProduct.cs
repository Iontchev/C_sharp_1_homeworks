﻿using System;

class Program
{
    static void Main()
    {
        double firstNum;
        double secondNum;
        double thirdNum;
        bool sign = true;
        Console.Write("Enter first number:");
        firstNum = double.Parse(Console.ReadLine());
        Console.Write("Enter second number:");
        secondNum = double.Parse(Console.ReadLine());
        Console.Write("Enter third number:");
        thirdNum = double.Parse(Console.ReadLine());
        if (firstNum < 0)
        {
            sign = !sign;
        }
        if (secondNum < 0)
        {
            sign = !sign;
        }
        if (thirdNum < 0)
        {
            sign = !sign;
        }
        if (sign)
        {
            Console.WriteLine("The product is positive:");
        }
        else
        {
            Console.WriteLine("The product is nagative:");
        }
    }
}

