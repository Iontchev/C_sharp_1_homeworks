﻿using System;


class InputDependingOnUserChoice
{
    static void Main()
    {
        Console.WriteLine("Choose what kind of variable you would like to enter.");
        Console.WriteLine("For int press 1");
        Console.WriteLine("for double press 2");
        Console.Write("for string press 3:");
        int userChoice = int.Parse(Console.ReadLine());
        switch (userChoice)
        {
            case 1:
                Console.Write("Enter your int variable: ");
                int intChoice = int.Parse(Console.ReadLine());
                Console.WriteLine(intChoice + 1);
                break;
            case 2:
                Console.Write("Enter your double variable: ");
                double doubleChoice = double.Parse(Console.ReadLine());
                Console.WriteLine(doubleChoice + 1.0);
                break;
            case 3:
                Console.Write("Enter your string variable: ");
                string strChoice = Console.ReadLine();
                Console.WriteLine(strChoice + "*");
                break;
        }
    }
}

